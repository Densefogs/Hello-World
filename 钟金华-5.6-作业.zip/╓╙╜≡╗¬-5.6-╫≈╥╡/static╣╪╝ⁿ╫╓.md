# static关键字

### 1：static修饰方法。

**通过类名直接调用，不推荐类对象进行操作。**

​		1：不能使用类内【非静态成员变量，非静态成员方法，this关键字】。

​		2：静态成员方法可以使用类内的其他静态成员变量和静态成员方法。

~~~java
class Car {

	public String name;

	public static String color = "白色";

	public Car() {
		super();
	}

	public static void test1() {

		System.out.println("静态成员方法");
	}

	public void test() {
		System.out.println("非静态成员方法");
	}
}

public class DemoStaticFF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 静态成员变量
		Car.color = "黄色";

		// 静态成员方法
		Car.test1();

		Car car = new Car();
		car.test();
	}
}
~~~

##### 从加载时间和销毁时间分析

~~~java
	1：类对象创建之前，静态成员方法可以直接调用执行。
    2：对象销毁之后，依然可以通过类名直接调用静态成员方法。
~~~



##### 静态成员方法的作用：

~~~java
	工具类！！！
    节约内存，复用度高
~~~

-------

-----

--------



### 2：static修饰成员变量。

​	**通过类名直接调用，不推荐类对象进行操作，因为与对象无关。**

​	**1：**静态成员变量不管通过哪种方式修改操作数据，都会影响到所有的使用者，因为**资源共享**。

​	**2：**静态成员变量在类对象创建之前可以使用，类对象销毁之后也可以使用，生存周期完成不同，所以静态成员变量与类对象无关。

~~~java
package com.zjh;

class Person {

	private String name;
	private int age;
	public static String country = "中华人民共和国";

	public Person() {
		super();
	}
    
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
    
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}
	public int getAge() {return age;}
	public void setAge(int age) {this.age = age;}
}

public class Demo1 {

	public static void main(String[] args) {

		Person person1 = new Person("张三", 15);
		Person person2 = new Person("李四", 25);


		System.out.println("name:" + person1.getName() + "  age:" + person1.getAge() + "  country:" + Person.country);
		System.out.println("name:" + person2.getName() + "  age:" + person2.getAge() + "  country:" + Person.country);

		// 静态成员变量不管通过哪种方式修改，都会影响到所有的使用者。
		person1.country = "中国";
		System.out.println("name:" + person1.getName() + "  age:" + person1.getAge() + "  country:" + person1.country);
		System.out.println("name:" + person2.getName() + "  age:" + person2.getAge() + "  country:" + person2.country);
	}
}
~~~

![image-20200506175249851](C:\Users\28253\AppData\Roaming\Typora\typora-user-images\image-20200506175249851.png)



##### 内存角度分析

~~~java
类对象：
    占用内存堆空间
静态成员变量：
    占用内存的数据区
    
类对象与静态成员变量所占用的内存空间不同，如果没有引用指向操作，两者不存在关系。
~~~

##### 代码加载过程分析

~~~java
分析 ：
	1：类对象创建之前，静态成员变量就可以使用了。
	2：在类对象被销毁后，静态成员变量依然可以使用。
    
代码加载原理性过程：
    1： .Java文件会通过Java编译器编译成对应的 .class字节码文件。
    2：在程序加载过程中， .class字节码文件会加载到内存的方法区，同时会按照对应的顺序结构 【从上到下，从左至右】完成.class文件的加载过程。
   
资源销毁过程：
	1：Java中存在的类对象，是通过该JVM中的GC(垃圾回收机制)销毁对象，回收内存。
	2：static静态成员变量是在整个程序退出之后，当前代码中不存在任何一块内存被类对象占用，JVM才会释放  .class文件所占用的方法区空间，同时销毁静态成员变量所占用的数据区空间。
~~~





---------

---

---



### Arrays工具类

##### 		String toString(任意数组类型);

##### 		Arrays.sort(int[] arr);

​				排序,升序

##### 		Arrays.binarySearch(数组名,  元素);

​				二分查找法（从中间开始找），找到对应的元素，返回值大于等于0，没有找到就返回负数

~~~java
import java.util.Arrays;

public class DemoArrays {

	public static void main(String[] args) {

		int[] array = { 1, 3, 5, 7, 9, 2, 4, 6, 8 };

		// 将数组转换为字符串形式展示
		String str = Arrays.toString(array);

		System.out.println(str);

		// 升序排序
		Arrays.sort(array);
		System.out.println(Arrays.toString(array));

		// 找出指定元素在数组中下标位置，不保证找到的元素是第几个
		int index = Arrays.binarySearch(array, 5);
		System.out.println(index);
	}
}
~~~



---

---



## 代码块

​		{}包含的

​				方法体代码块，分支结构代码块，循环结构代码块



#### 构造代码块

~~~java
功能：
    初始化当前类所有的类对象，只要使用new + 构造方法创建当前类对象，就一定会执行构造代码块中的内容。
~~~

~~~java
class Person1 {

	private String name;

	// 构造代码块
	{
		System.out.println("构造代码块执行。。。。。");
	}

	public Person1() {
		super();
	}

	public Person1(String name) {
		super();
		this.name = name;
	}
}

public class DemoGGDMK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new Person1();
		new Person1();
		new Person1();
		new Person1();
	}
}
运行结果：
    构造代码块执行。。。。。
	构造代码块执行。。。。。
	构造代码块执行。。。。。
	构造代码块执行。。。。。
~~~



#### 静态代码块

static {}

**类加载的时候**静态代码块有且只会执行一次。

~~~java
class Dog {

	static {
		System.out.println("静态代码块执行");
	}

	public static void test() {
		System.out.println("Dog类成员方法");
	}
}

public class DemoJTDMK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Dog.test();
		Dog.test();
		Dog.test();

	}
}
运行结果：
    静态代码块执行
	Dog类成员方法
	Dog类成员方法
	Dog类成员方法
~~~





<img src="C:\Users\28253\AppData\Roaming\Typora\typora-user-images\image-20200506165849193.png" alt="image-20200506165849193"  />



---

---

---

# 面试题

~~~java
public class Demo2 {

	static Demo2 demo1 = new Demo2();
	static Demo2 demo2 = new Demo2();

	static {
		System.out.println("静态代码块");
	}

	public Demo2() {
		System.out.println("构造方法");
	}

	{
		System.out.println("构造代码块");
	}

	public static void main(String[] args) {

		Demo2 Demo = new Demo2();
	}
}
运行结果：
    构造代码块-->构造方法-->构造代码块-->构造方法-->静态代码块--构造代码块-->构造方法
~~~

~~~java
代码块执行流程：
    【构造代码块】与【构造方法】放的顺序无关，不影响结果，优先执行构造代码块，在执行构造方法
~~~



![image-20200506215237716](C:\Users\28253\AppData\Roaming\Typora\typora-user-images\image-20200506215237716.png)



